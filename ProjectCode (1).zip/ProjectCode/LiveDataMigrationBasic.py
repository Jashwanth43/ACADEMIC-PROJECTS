import random
import time
import pandas as pd
from datetime import datetime, timedelta
import influxdb_client, os, time
from influxdb_client import InfluxDBClient, Point, WritePrecision
from influxdb_client.client.write_api import SYNCHRONOUS
from config import (
    influxdb_connection_params, 
    influx_bucket,
    influx_measurment,
    influx_org,
)

# Migrate data to InfluxDB
def migrate_to_influxdb(df_influx, influx_client, influx_bucket, influx_measurment, influx_org):
    try:
      # Creating a write API for InfluxDB
      write_api = influx_client.write_api(write_options=SYNCHRONOUS)
      # Iterating through each row of the DataFrame and writing data to InfluxDB
      for index,row in df_influx.iterrows():
        point = (
          Point(influx_measurment)
          .time(row["timestamp"])
          .tag("station_id",row["station_id"], )
          .field(row["parameter"], row["value"])
        )
        write_api.write(bucket=influx_bucket, org=influx_org, record=point)
    except Exception as e:
       # Handling exceptions and printing an error message
       print("=============================================================================")
       print("Error when migrating to influx: ",e)
       print("=============================================================================")


# Main execution block
def generate_live_data():
    startDate = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    numberOfDays = 1
    parameterIds = range(1, 4)
    stationIds = range(1, 6)
    try:
        influx_client = influxdb_client.InfluxDBClient(**influxdb_connection_params)
        data_list=[]
        parameter=""
        for _ in range(numberOfDays):
            print(startDate)
            currentTime = startDate
            for _ in range(24):  # 24 hours in a day
                for _ in range(60):  # 60 records per hour
                    for stationId in stationIds:
                        for parameterId in parameterIds:
                            timeStamp = currentTime.strftime('%Y-%m-%d %H:%M:%S')
                            if parameterId == 1:
                                value = random.uniform(-10, 40)
                                parameter = "Temperature"
                            elif parameterId == 2:
                                value = random.uniform(10, 90)
                                parameter = "Humidity"
                            else:
                                value = random.uniform(0.1, 100)
                                parameter = "Precipitation"
                            record = {
                                'station_id': stationId,
                                'parameter': parameter,
                                'timestamp': timeStamp,
                                'value': value
                            } 
                            data_list.append(record)
                            df_influx = pd.DataFrame(data_list)
                            df_influx['timestamp'] = pd.to_datetime(df_influx['timestamp'])
                            df_influx['timestamp'] = pd.to_datetime(df_influx['timestamp']).dt.strftime('%Y-%m-%dT%H:%M:%SZ')
                            print(df_influx)
                            migrate_to_influxdb(df_influx, influx_client, influx_bucket,influx_measurment, influx_org)
                    #wait for 15 secs to generate next data       
                    time.sleep(15)
                    currentTime += timedelta(minutes=1)  # Increment timestamp by 1 minute
            startDate += timedelta(days=1)
        print("inserted successfully")
    except Exception as e:
        print(e)

if __name__ == "__main__":
    generate_live_data()