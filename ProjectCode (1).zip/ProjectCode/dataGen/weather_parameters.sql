INSERT INTO test_weather13.weather_parameters (parameter_name) VALUES
    ('Temperature'),
    ('Humidity'),
    ('Precipitation');