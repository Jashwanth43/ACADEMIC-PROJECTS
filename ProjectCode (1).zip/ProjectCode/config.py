#mySQL connection parameters
mysql_connection_params = {
    'host': 'localhost',
    'user': 'root',
    'password': 'jayasri',
    'database': 'test_weather16',
}

#InfluxDB connection parameters
influxdb_connection_params = {
    'url': 'http://localhost:8086',
    'token': "QE6fZAqb3JdjWtUxrj3JdhYqblTPwrkdC_sCQa0uJJ1KWv8dytQwNH-tGn8QzP3LVnFB9BzzQS56Q6gQGhOiOQ==",
    'org': 'cps691group4',
}

#postGIS connection parameters
postgis_connection_params = {
    'host': 'localhost',
    'port': 5432,
    'database': 'postgis_34_sample',
    'user': 'postgres',
    'password': 'jayasri',
}


influx_measurment="weather_timeseries72"

influx_bucket="test3"

influx_org = "cps691group4"

num_threads = 16

postgis_table_name = "test_weatherspatial69"

influxDataFile = "influxData.csv"
postGisDataFile = "postGisData.csv"






